function calculateFinalSpeed(speed, SpeedChange) {
    if(speed > 0){
    for (let i = 0; i < SpeedChange.length; i++) {
       
        if (SpeedChange[i] < 0) {
            speed += (SpeedChange[i]) * -1;
        } else if (SpeedChange[i] > 0) {
            speed -= SpeedChange[i];
        }
    }
    
    if (speed < 0) {
        speed = 0;
    }
}
 else {
    speed = 0
}
    return speed;
}

console.log(calculateFinalSpeed(60, [0, 30, 0, -45, 0]));

